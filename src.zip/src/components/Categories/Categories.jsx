const Categories = () => {
    return (
        <>
            <div className="container">

                <div class="line">
                    <h1 class="heading">Centered Heading</h1>
                </div>
            </div>

        </>
    );
}

export default Categories;