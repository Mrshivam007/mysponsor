import img1 from "../assets/img/card/mobile-cards.jpg";
import img2 from "../assets/img/card/mobile-cards2.jpg";
import img3 from "../assets/img/card/mobile-cards3.jpg";
import img4 from "../assets/img/card/mobile-cards4.jpg";

export const ContentCreators4 = [
  {
    id: 1,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  {
    id: 2,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  {
    id: 3,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  {
    id: 4,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  // Add more data objects as needed
];
export const ContentCreators8 = [
  {
    id: 1,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  {
    id: 2,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  {
    id: 3,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  {
    id: 4,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  {
    id: 5,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  {
    id: 6,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  {
    id: 7,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  {
    id: 8,
    name: "Mr. Beast",
    platform: "Youtube",
    price: "1 Million <",
    people: "50 Million",
  },
  // Add more data objects as needed
];

export const EventsCards = [
  {
    id: 1,
    name: "Ganesh Chaturthi",
    location: "Durg, C.G.",
    price: "$10,000<",
    people: "1 Million+",
    img: img1,
  },
  {
    id: 2,
    name: "Ganesh Chaturthi",
    location: "Durg, C.G.",
    price: "$10,000<",
    people: "1 Million+",
    img: img2,
  },
  {
    id: 3,
    name: "Ganesh Chaturthi",
    location: "Durg, C.G.",
    price: "$10,000<",
    people: "1 Million+",
    img: img3,
  },
  {
    id: 4,
    name: "Ganesh Chaturthi",
    location: "Durg, C.G.",
    price: "$10,000<",
    people: "1 Million+",
    img: img4,
  },
  // Add more data objects as needed
];
export const EventsPageCards = [
  {
    id: 1,
    // name: "Ganesh Chaturthi",
    // location: "Durg, C.G.",
    img: img1,
  },
  {
    id: 2,
    // name: "Dussehra",
    // location: "Sec-10, Bhilai",
    img: img2,
  },
  {
    id: 3,
    // name: "ColdPlay",
    // location: "St.Pualo, Brazil",
    img: img3,
  },
  {
    id: 4,
    name: "Offset",
    location: "Rollin Loud, Miami",
    img: img4,
  },
  {
    id: 5,
    // name: "Ganesh Chaturthi",
    // location: "Durg, C.G.",
    img: img1,
  },
  {
    id: 6,
    // name: "Dussehra",
    // location: "Sec-10, Bhilai",
    img: img2,
  },
  {
    id: 7,
    // name: "ColdPlay",
    // location: "St.Pualo, Brazil",
    img: img3,
  },
  {
    id: 8,
    name: "Offset",
    location: "Rollin Loud, Miami",
    img: img4,
  },
  {
    id: 9,
    // name: "Ganesh Chaturthi",
    // location: "Durg, C.G.",
    img: img1,
  },
  {
    id: 10,
    // name: "Dussehra",
    // location: "Sec-10, Bhilai",
    img: img2,
  },
  {
    id: 11,
    // name: "ColdPlay",
    // location: "St.Pualo, Brazil",
    img: img3,
  },
  {
    id: 12,
    name: "Offset",
    location: "Rollin Loud, Miami",
    img: img4,
  },
];

export const ChoicePageCards = [
  {
    id: 1,
    // name: "Ganesh Chaturthi",
    // location: "Durg, C.G.",
    img: img1,
  },
  {
    id: 2,
    // name: "Dussehra",
    // location: "Sec-10, Bhilai",
    img: img2,
  },
  {
    id: 3,
    // name: "ColdPlay",
    // location: "St.Pualo, Brazil",
    img: img3,
  },
  {
    id: 4,
    name: "Offset",
    location: "Rollin Loud, Miami",
    img: img4,
  },
];
